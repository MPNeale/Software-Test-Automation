package test;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import contactservice.Contact;
import contactservice.ContactService;


public class ContactServiceTest {
	
	// test for addContact method
	@Test
	void testContactServiceAddContact() {
		Contact contact = new Contact("123", "Bob", "Bobson", "1234567890", "123 Bob Street");
		Contact contact2 = new Contact("123", "Bobs", "Bobsons", "2234567890", "124 Bob Street");
		ArrayList<Contact> contactList = new ArrayList<Contact>();
		
		ContactService.addContact(contact, contactList);
		
		// test adding second contact with same ID
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			ContactService.addContact(contact2, contactList);
		});
	
		assertEquals(contactList.get(0), contact);
		assertTrue(contactList.size() == 1);
	}
	
	// test for deleteContact method
	@Test
	void testContactServiceDeleteContact() {
		Contact contact = new Contact("123", "Bob", "Bobson", "1234567890", "123 Bob Street");
		Contact contact2 = new Contact("1234", "Bobs", "Bobsons", "2234567890", "124 Bob Street");
		ArrayList<Contact> contactList = new ArrayList<Contact>();
		
		// add two contacts
		ContactService.addContact(contact, contactList);
		ContactService.addContact(contact2, contactList);
		
		// size should be 2
		assertTrue(contactList.size() == 2);
		
		// delete one contact
		ContactService.deleteContact("1234", contactList);
		
		//size should be 1
		assertTrue(contactList.size() == 1);
		assertEquals(contactList.get(0), contact);
	}
	
	// test name changes
	@Test
	void testContactServiceSetNames() {
		Contact contact = new Contact("123", "Bob", "Bobson", "1234567890", "123 Bob Street");
		ArrayList<Contact> contactList = new ArrayList<Contact>();
		
		// add contact
		ContactService.addContact(contact, contactList);
		
		// update names
		ContactService.setFirstName("123", "John", contactList);
		ContactService.setLastName("123", "Johnson", contactList);
		
		// test name changes
		assertTrue(contactList.get(0).getFirstName().equals("John"));
		assertTrue(contactList.get(0).getLastName().equals("Johnson"));
	}
	
	// test phone change
	@Test
	void testContactServiceSetPhone() {
		Contact contact = new Contact("123", "Bob", "Bobson", "1234567890", "123 Bob Street");
		ArrayList<Contact> contactList = new ArrayList<Contact>();
		
		// add contact
		ContactService.addContact(contact, contactList);
		
		// update name
		ContactService.setPhone("123", "0987654321", contactList);
		
		// test name change
		assertTrue(contactList.get(0).getPhone().equals("0987654321"));
	}
	
	// test address change
	@Test
	void testContactServiceSetAddress() {
		Contact contact = new Contact("123", "Bob", "Bobson", "1234567890", "123 Bob Street");
		ArrayList<Contact> contactList = new ArrayList<Contact>();
		
		// add contact
		ContactService.addContact(contact, contactList);
		
		// update name
		ContactService.setAddress("123", "546 Taco Blvd", contactList);
		
		// test name change
		assertTrue(contactList.get(0).getAddress().equals("546 Taco Blvd"));
	}

}
