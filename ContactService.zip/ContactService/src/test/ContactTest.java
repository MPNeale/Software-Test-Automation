package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import contactservice.Contact;

public class ContactTest {
	
	@Test
	void testContact() {
		Contact contact = new Contact("123", "Bob", "Bobson", "1234567890", "123 Bob Street");
		assertTrue(contact.getID().equals("123"));
		assertTrue(contact.getFirstName().equals("Bob"));
		assertTrue(contact.getLastName().equals("Bobson"));
		assertTrue(contact.getPhone().equals("1234567890"));
		assertTrue(contact.getAddress().equals("123 Bob Street"));
	}
	
	@Test
	void testContactIDTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("12345678900", "Bob", "Bobson", "1234567890", "123 Bob Street");
		});
	}
	
	@Test
	void testContactIDNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact(null, "Bob", "Bobson", "1234567890", "123 Bob Street");
		});
	}
	
	@Test
	void testContactFirstNameTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("123", "Bobobobobob", "Bobson", "1234567890", "123 Bob Street");
		});
	}
	
	@Test
	void testContactFirstNameNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("123", null, "Bobson", "1234567890", "123 Bob Street");
		});
	}
	
	@Test
	void testContactLastNameTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("123", "Bob", "Bobsonosbob", "1234567890", "123 Bob Street");
		});
	}
	
	@Test
	void testContactLastNameNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("123", "Bob", null, "1234567890", "123 Bob Street");
		});
	}
	
	@Test
	void testContactPhoneTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("123", "Bob", "Bobson", "12345678900", "123 Bob Street");
		});
	}
	
	@Test
	void testContactPhoneTooShort() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("123", "Bob", "Bobson", "12345", "123 Bob Street");
		});
	}
	
	@Test
	void testContactPhoneNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("123", "Bob", "Bobson", null, "123 Bob Street");
		});
	}
	
	@Test
	void testContactAddressTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("123", "Bob", "Bobson", "1234567890", "123 Bob Street BobTown BO 54321 BSA");
		});
	}
	
	@Test
	void testContactAddressNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("123", "Bob", "Bobson", "12345678900", null);
		});
	}

}
