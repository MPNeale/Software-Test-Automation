package contactservice;
import java.util.ArrayList;

public class ContactService {

	public static void addContact(Contact contact, ArrayList<Contact> list) {
		for (int i = 0; i < list.size(); i++) {
			if (list.get(i).ID.equals(contact.ID)) {
				throw new IllegalArgumentException("Invalid ID");
			}
				
		}
		list.add(contact);
	}
	
	public static void deleteContact(String contactID, ArrayList<Contact> list) {
		for (int i = 0; i < list.size(); i++) {
			if (list.get(i).ID.equals(contactID)) {
				list.remove(list.get(i));
			}
		}
	}
	
	public static void setFirstName(String contactID, String name, ArrayList<Contact> list) {
		for (int i = 0; i < list.size(); i++) {
			if (list.get(i).ID.equals(contactID)) {
				list.get(i).firstName = name;
			}
		}
	}
	
	public static void setLastName(String contactID, String name, ArrayList<Contact> list) {
		for (int i = 0; i < list.size(); i++) {
			if (list.get(i).ID.equals(contactID)) {
				list.get(i).lastName = name;
			}
		}
	}
	
	public static void setPhone(String contactID, String phone, ArrayList<Contact> list) {
		for (int i = 0; i < list.size(); i++) {
			if (list.get(i).ID.equals(contactID)) {
				list.get(i).phone = phone;
			}
		}
	}
	
	public static void setAddress(String contactID, String address, ArrayList<Contact> list) {
		for (int i = 0; i < list.size(); i++) {
			if (list.get(i).ID.equals(contactID)) {
				list.get(i).address = address;
			}
		}
	}
}
