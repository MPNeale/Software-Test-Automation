package test;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Date;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import appointmentservice.Appointment;

class AppointmentTest {

	@Test
	void testAppointment() {
		Date date = new Date(2022, 8, 30);
		Appointment appt = new Appointment("123", date, "Appointment Description");
			assertTrue(appt.getID().equals("123"));
			assertTrue(appt.getAppointmentDate().equals(date));
			assertTrue(appt.getDescription().equals("Appointment Description"));
	}
	
	@Test
	void testAppointmentIDTooLong() {
		Date date = new Date(2022, 8, 30);
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Appointment("12345678900", date, "Appointment Description");
		});
	}
	
	@Test
	void testAppointmentIDNull() {
		Date date = new Date(2022, 8, 30);
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Appointment(null , date, "Appointment Description");
		});
	}
	
	@Test
	void testAppointmentDatePast() {
		Date date = new Date(1995);
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Appointment("123", date, "Appointment Description");
		});
	}
	
	@Test
	void testAppointmentDateNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Appointment("123", null, "Appointment Description");
		});
	}
	
	@Test
	void testAppointmentDescriptionTooLong() {
		Date date = new Date(2022, 8, 30);
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Appointment("123", date, "Appointment Description that is too long with lots of words making it too long and add some more words and other words");
		});
	}
	
	@Test
	void testAppointmentDescriptionNull() {
		Date date = new Date(2022, 8, 30);
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Appointment("123", date, null);
		});
	}

}
