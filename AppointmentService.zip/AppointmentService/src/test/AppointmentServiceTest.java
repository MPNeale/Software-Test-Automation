package test;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.Date;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import appointmentservice.Appointment;
import appointmentservice.AppointmentService;

class AppointmentServiceTest {

	@Test
	void testAppointmentServiceAddAppointment() {
		Date date = new Date(2022, 8, 30);
		Appointment appt = new Appointment("123", date, "Appointment Description");
		Appointment appt2 = new Appointment("123", date, "Appointment Description");
		ArrayList<Appointment> apptList = new ArrayList<Appointment>();
		
		AppointmentService.addAppointment(appt, apptList);
		
		// test adding second appointment with same ID
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			AppointmentService.addAppointment(appt2, apptList);
		});
	
		assertEquals(apptList.get(0), appt);
		assertTrue(apptList.size() == 1);
	}
	
	// test for deleteAppointment method
	@Test
	void testAppointmentServiceDeleteAppointment() {
		Date date = new Date(2022, 8, 30);
		Appointment appt = new Appointment("123", date, "Appointment Description");
		Appointment appt2 = new Appointment("1234", date, "Appointment Description");
		ArrayList<Appointment> apptList = new ArrayList<Appointment>();
		
		// add two tasks
		AppointmentService.addAppointment(appt, apptList);
		AppointmentService.addAppointment(appt2, apptList);
		
		// size should be 2
		assertTrue(apptList.size() == 2);
		
		// delete one task
		AppointmentService.deleteAppointment("1234", apptList);
		
		//size should be 1
		assertTrue(apptList.size() == 1);
		assertEquals(apptList.get(0), appt);
	}

}
