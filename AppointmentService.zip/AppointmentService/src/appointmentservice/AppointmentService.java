package appointmentservice;

import java.util.ArrayList;

public class AppointmentService {

	public static void addAppointment(Appointment appt, ArrayList<Appointment> list) {
		for (int i = 0; i < list.size(); i++) {
			if (list.get(i).ID.equals(appt.ID)) {
				throw new IllegalArgumentException("Invalid ID");
			}
				
		}
		list.add(appt);
	}
	
	public static void deleteAppointment(String apptID, ArrayList<Appointment> list) {
		for (int i = 0; i < list.size(); i++) {
			if (list.get(i).ID.equals(apptID)) {
				list.remove(list.get(i));
			}
		}
	}
}
