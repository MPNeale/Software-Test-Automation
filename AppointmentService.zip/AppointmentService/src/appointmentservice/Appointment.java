package appointmentservice;
import java.util.Date;

public class Appointment {
	
	protected final String ID;
	protected Date appointmentDate;
	protected String description;
	
	public Appointment(String ID, Date date, String description) {
		
		if(ID == null || ID.length()>10)
			throw new IllegalArgumentException("Invalid ID");
		
		if(date == null || date.before(new Date()))
			throw new IllegalArgumentException("Invalid Date");
		
		if(description == null || description.length()>50)
			throw new IllegalArgumentException("Invalid Description");
		
		this.ID = ID;
		this.appointmentDate = date;
		this.description = description;
	}
	
	public String getID() {
		return ID;
	}
	
	public Date getAppointmentDate() {
		return appointmentDate;
	}
	
	public String getDescription() {
		return description;
	}

}
