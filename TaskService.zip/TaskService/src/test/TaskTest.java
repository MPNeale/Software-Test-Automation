package test;

import static org.junit.jupiter.api.Assertions.*;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import taskservice.Task;

public class TaskTest {
	
	// test for task constructor
	@Test
	void testTask() {
		Task task = new Task("123", "Do things", "Description of doing things");
		assertTrue(task.getID().equals("123"));
		assertTrue(task.getName().equals("Do things"));
		assertTrue(task.getDescription().equals("Description of doing things"));
	}
	
	@Test
	void testTaskIDTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Task("12345678900", "Do things", "Description of doing things");
		});
	}
	
	@Test
	void testTaskIDNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Task(null, "Do things", "Description of doing things");
		});
	}
	
	@Test
	void testTaskNameTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Task("123", "Do things and also other things and more things", "Description of doing things");
		});
	}
	
	@Test
	void testTaskNameNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Task("123", null, "Description of doing things");
		});
	}
	
	@Test
	void testTaskDescriptionTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Task("123", "Do things", "Description of doing things that is more than 50 characters which would make it much much too long");
		});
	}
	
	@Test
	void testTaskDescriptionNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Task("123", "Do things", null);
		});
	}

}
