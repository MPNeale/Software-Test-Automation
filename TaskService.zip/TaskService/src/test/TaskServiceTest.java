package test;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import taskservice.Task;
import taskservice.TaskService;

public class TaskServiceTest {
	
	// test for addTask method
	@Test
	void testTaskServiceAddTask() {
		Task task = new Task("123", "Do things", "Description of doing things");
		Task task2 = new Task("123", "Do thingies", "Description of doing things");
		ArrayList<Task> taskList = new ArrayList<Task>();
		
		TaskService.addTask(task, taskList);
		
		// test adding second task with same ID
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			TaskService.addTask(task2, taskList);
		});
	
		assertEquals(taskList.get(0), task);
		assertTrue(taskList.size() == 1);
	}
	
	// test for deleteTask method
	@Test
	void testTaskServiceDeleteTask() {
		Task task = new Task("123", "Do things", "Description of doing things");
		Task task2 = new Task("1234", "Do thingies", "Description of doing things");
		ArrayList<Task> taskList = new ArrayList<Task>();
		
		// add two tasks
		TaskService.addTask(task, taskList);
		TaskService.addTask(task2, taskList);
		
		// size should be 2
		assertTrue(taskList.size() == 2);
		
		// delete one task
		TaskService.deleteTask("1234", taskList);
		
		//size should be 1
		assertTrue(taskList.size() == 1);
		assertEquals(taskList.get(0), task);
	}
	
	// test name change
	@Test
	void testTaskServiceSetName() {
		Task task = new Task("123", "Do things", "Description of doing things");
		ArrayList<Task> taskList = new ArrayList<Task>();
		
		// add task
		TaskService.addTask(task, taskList);
		
		// update name
		TaskService.setName("123", "Something else", taskList);
		
		// test name change
		assertTrue(taskList.get(0).getName().equals("Something else"));	
	}
	
	// test description change
	@Test
	void testTaskServiceSetDescription() {
		Task task = new Task("123", "Do things", "Description of doing things");
		ArrayList<Task> taskList = new ArrayList<Task>();
		
		// add task
		TaskService.addTask(task, taskList);
		
		// update description
		TaskService.setDescription("123", "A different description", taskList);
		
		// test description change
		assertTrue(taskList.get(0).getDescription().equals("A different description"));
	}

}
