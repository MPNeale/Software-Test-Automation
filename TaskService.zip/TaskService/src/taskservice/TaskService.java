package taskservice;
import java.util.ArrayList;

public class TaskService {
	
	public static void addTask(Task task, ArrayList<Task> list) {
		for (int i = 0; i < list.size(); i++) {
			if (list.get(i).ID.equals(task.ID)) {
				throw new IllegalArgumentException("Invalid ID");
			}
				
		}
		list.add(task);
	}
	
	public static void deleteTask(String taskID, ArrayList<Task> list) {
		for (int i = 0; i < list.size(); i++) {
			if (list.get(i).ID.equals(taskID)) {
				list.remove(list.get(i));
			}
		}
	}
	
	public static void setName(String taskID, String name, ArrayList<Task> list) {
		for (int i = 0; i < list.size(); i++) {
			if (list.get(i).ID.equals(taskID)) {
				list.get(i).name = name;
			}
		}
	}
	
	public static void setDescription(String taskID, String name, ArrayList<Task> list) {
		for (int i = 0; i < list.size(); i++) {
			if (list.get(i).ID.equals(taskID)) {
				list.get(i).description = name;
			}
		}
	}

}
