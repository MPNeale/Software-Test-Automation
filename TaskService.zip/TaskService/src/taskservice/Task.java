package taskservice;

public class Task {

	protected final String ID;
	protected String name;
	protected String description;
	
	public Task(String ID, String name, String description) {
		
		if(ID == null || ID.length()>10)
			throw new IllegalArgumentException("Invalid ID");
		
		if(name == null || name.length()>20)
			throw new IllegalArgumentException("Invalid name");
		
		if(description == null || description.length()>50)
			throw new IllegalArgumentException("Invalid description");
		
		this.ID = ID;
		this.name = name;
		this.description = description;
	}
	
	public String getID() {
		return ID;
	}
	
	public String getName() {
		return name;
	}
	
	public String getDescription() {
		return description;
	}
}
